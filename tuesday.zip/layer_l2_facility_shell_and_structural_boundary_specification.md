# Stratum L2: Facility Shell & Structural Boundary Engineering Specification

**Strata Layer:** L2 (Lower Mantle / Physical & Structural Envelope)  
**Parent Document:** `12 - Lab Stack Strata — Ground-Up Layer Matrix.md`  
**Security Classification Boundary:** Band A (CUI Enclave) vs. Band B (ICD 705 SCIF Enclave)  
**Circulation Paradigm:** External Mantrap Air-Lock Entry to Central Secure Corridor  

---

## 1. System Engineering Architecture

Layer L2 defines the physical boundary separating the exterior environment and general building envelope from the secure data processing zones. Band B must adhere strictly to Intelligence Community Directive 705 (ICD 705) standards for physical, acoustic, and radio-frequency (RF) containment.

```text
[Exterior Physical Perimeter] (K-Rated Anti-Ram Fence & Clear Zone)
       │
       ▼
[Substructure Foundation] (6-Sided Concrete Box / True Slab-to-Slab)
       ├──► Band A: Slab-to-deck drywall (5/8" Type X, double layer) + Drop ceiling
       │
       ├──► Central Corridor & External Mantrap: Interlocking steel blast doors
       │
       └──► Band B (ICD 705 SCIF Boundary):
                 ├── Outer Reinforced Concrete Structural Wall ($200\text{ mm} - 300\text{ mm}$)
                 ├── 360-Degree Inspectable Crawlway (Above ceiling & below raised floor)
                 ├── 9-Gauge Expanded Metal / Welded Steel Anti-Intrusion Mesh
                 ├── Continuous RF Attenuation Foil / Copper Mesh Shielding ($>100\text{ dB}$)
                 ├── Sound Transmission Class (STC) 50+ Acoustic Batting & Sealants
                 └── Non-Conductive Waveguide Honeycomb Air Vents on all duct penetrations
```

---

## 2. Band A vs. Band B Detailed Technical Breakdown

| Metric / Component | Band A: Unclassified / CUI Lab | Band B: Classified / SCIF Lab |
| :--- | :--- | :--- |
| **Standard / Compliance** | NIST SP 800-171 / CMMC Level 2 physical criteria | **ICD 705 / ICS 705-1 / TEMPEST Zone A/B** |
| **Wall Construction** | Double-layer 5/8" Type X Gypsum on steel studs | True slab-to-slab reinforced concrete + 9-gauge expanded steel mesh |
| **Acoustic Rating** | Standard office commercial acoustic rating ($\sim \text{STC } 35$) | **STC 50 or STC 55** (Sound Group 3/4 per ICD 705) |
| **RF / TEMPEST Shielding**| None | Continuous copper foil or welded steel lining offering $\ge 100\text{ dB}$ attenuation |
| **Inspectability** | Hard ceilings with inspection hatches | **Continuous inspectable crawl space** above ceiling grid and below access floor |
| **Penetration Protection** | Intumescent firestop collars on pipe/cable sleeves | Welded steel pipe collars, waveguide below cut-off frequency, no man-passable openings ($>96 \text{ in}^2$) without steel bars |
| **Doors & Hardware** | Hollow metal doors with commercial mortise locksets | Sound-rated SCIF steel doors, acoustic cam-lift hinges, dual perimeter gasketing |

---

## 3. Boundary Penetration & Physical Security Enclosure

1. **Anti-Intrusion Steel Core:**
   * The classified shell is lined with 9-gauge expanded metal welded to heavy structural steel framing studs at $150\text{ mm}$ centers, preventing physical penetration via rotary cutting tools or sledgehammers.
2. **RF Waveguide Vents:**
   * Air duct penetrations exceeding $150\text{ mm}$ diameter must pass through brass/copper RF waveguide honeycomb assemblies sized below the cutoff frequency ($>10\text{ GHz}$) to prevent radiated electromagnetic egress.
3. **Inspectable Man-Passable Boundary:**
   * Any duct or opening exceeding $96 \text{ sq inches}$ ($620 \text{ cm}^2$) with a smallest dimension greater than $6 \text{ inches}$ ($150\text{ mm}$) must be fitted with $1/2\text{ inch}$ ($12.7\text{ mm}$) case-hardened steel bars spaced $6\text{ inches}$ on center, fully inspectable from the crawl space.

---

## 4. Architectural Section Diagram Reproduction Prompt

Below is the detailed visual generation prompt to create the technical cross-section blueprint for this layer:

```text
An architectural section elevation blueprint of Layer L2 Facility Shell & Structural Boundary, 16:9 widescreen ratio with engineering borders, dimension callouts, and material hatch standards.
Cross-section layout from left to right:
1. Far Left: Exterior security clear zone with heavy anti-ram perimeter fence, security bollards, and concrete foundation tie-ins.
2. Band A (Unclassified / CUI Lab): Conventional commercial construction showing slab-to-deck drywall framing, standard suspended ceiling grid, standard interior hollow metal doors, and unshielded ductwork.
3. Center Core: Central secure hallway corridor connected to an exterior-facing security airlock mantrap with interlocking certified heavy steel doors.
4. Band B (Classified SCIF Lab): Full accredited ICD 705 physical shell cross-section showing a true 6-sided reinforced concrete boundary; continuous 360-degree inspectable crawlway space above the acoustic drop ceiling and beneath the raised pedestal floor; wall layers visibly detailed with 9-gauge expanded metal anti-intrusion mesh, continuous RF copper attenuation foil, and STC 50+ acoustic insulation batting; all HVAC ductwork penetrating the boundary fitted with RF waveguide honeycomb air vents and hardened security inspection grilles.
Style: Professional architectural section cut, CAD drawing lines, concrete cross-hatch patterning, earth stipple, subtle gray shading (#F4F4F4), and clean red structural perimeter boundary line (#C8102E). Clean, competition-board presentation.
```