# Stratum L6: Network Fabrics & Cross-Domain Boundary Specification

**Strata Layer:** L6 (Signal Highway / Data Planes & Boundaries)  
**Parent Document:** `12 - Lab Stack Strata — Ground-Up Layer Matrix.md`  
**Security Classification Boundary:** Band A (CUI Enclave) vs. Band B (ICD 705 SCIF Enclave)  
**Circulation Paradigm:** External Mantrap Air-Lock Entry to Central Secure Corridor  

---

## 1. System Engineering Architecture

Layer L6 governs the data, storage, management, and cross-domain boundary networks. The primary engineering rule is the strict isolation of the classified RED data plane, an air-gapped out-of-band management plane, and a hardware-enforced one-way data diode bridging unclassified data imports into the classified enclave.

```text
[Band A: Unclassified / CUI Enclave]
       │
       ▼ (10GbE / 25GbE Corporate Campus Backbone)
[L6 Boundary Ingestion Appliance]
       │
       ▼ (Transmit-Only Fiber Core / Photodiode Disconnected)
╔═══════════════════════════════════════════════════════════════════╗
║       HARDWARE DATA DIODE (Physical Unidirectional Barrier)       ║
║  [TX Laser Optical Emitter] ───► ───► [RX Photodiode Receiver]   ║
╚═══════════════════════════════════════════════════════════════════╝
                                              │
                                              ▼ (Receive-Only Fiber Core)
[Band B: Classified / SCIF Enclave]
       ├──► RED Compute Fabric: Quantum-2 400G InfiniBand / 400GbE RoCE (GPU-to-GPU)
       ├──► RED Storage Fabric: Dedicated NVMe-oF / RDMA Network
       ├──► Isolated OOB Fabric: Physical Air-Gapped 1GbE Management Network (BMC/iDRAC)
       └──► Cross-Domain Solution (CDS): High-Assurance Guard for Bi-Directional Metadata
```

---

## 2. Band A vs. Band B Detailed Technical Breakdown

| Metric / Component | Band A: Unclassified / CUI Lab | Band B: Classified / SCIF Lab |
| :--- | :--- | :--- |
| **Compute Interconnect** | Standard 25GbE / 100GbE Ethernet switches | **400Gbps InfiniBand (Quantum-2) or 400GbE RoCE** lossless fabric |
| **Management / OOB Plane**| Shared management VLAN routed to enterprise NOC | **Physically separated, air-gapped 1GbE network** with no route to data plane |
| **Cross-Domain Transfer** | Internet/Cloud firewalls (Stateful inspection / TLS) | **Certified Hardware Data Diode (Low-to-High)** + High Assurance Guard |
| **Optical Cabling Spec** | Standard OM4 multimode fiber (aqua/violet jackets) | **Single-mode OS2 fiber with bright RED jackets** for all classified data |
| **Wide-Area Connectivity** | IPsec VPN tunnels across public internet | **Type 1 Cryptographic Encryptors (e.g., TACLANE KG-175G / KGV)** |
| **Physical Port Security** | Software 802.1X port security | 802.1X + **physical lockable RJ45/SFP port blocker plugs** on all empty ports |

---

## 3. Physical Boundary Data Diode Specification

1. **Physical Layer Unidirectionality:**
   * The data diode utilizes an optical transmitter (laser) on the Band A side connected via a single strand of single-mode fiber to an optical receiver (photodiode) on the Band B side. The return optical strand is physically omitted, making electromagnetic data egress mathematically and physically impossible ($0.00\text{ bps}$ reverse flow).
2. **Buffer & Protocol Break:**
   * Streaming unclassified datasets, model weights, or security patches terminate at an untrusted buffer server in Band A, stream across the UDP/FPGA optical link, and assemble on a trusted staging server inside Band B for antivirus and cryptographic signature validation.

---

## 4. Architectural Section Diagram Reproduction Prompt

Below is the detailed visual generation prompt to create the technical cross-section blueprint for this layer:

```text
An architectural cross-section blueprint of Layer L6 Network Fabrics & Cross-Domain Boundaries, 16:9 ratio with network schematic overlays and engineering borders.
Left to right layout:
1. Band A (Unclassified / CUI Lab): Top-of-Rack commercial Ethernet switches, blue Cat6A patch cabling, and standard fiber optic distribution panels connected to campus IT.
2. Center SCIF Perimeter Wall: Hardware Data Diode appliance chassis mounted directly through the concrete boundary wall. Cutaway shows the optical transmission path: a single transmit-only fiber strand running from the unclassified laser source through a sealed pipe penetration directly into the classified photodiode receiver, with no physical return path.
3. Band B (Classified SCIF Lab): High-speed RED network architecture consisting of Quantum-2 400Gbps InfiniBand switches, dedicated RoCE storage switches, bright red fiber optic patch cords routed through isolated yellow FiberRunner raceways; an independent physical 1GbE Out-of-Band (OOB) switch rack for server BMCs; and rack-mounted Type 1 HAIPE encryption devices (TACLANE) with keyed physical ignition keys.
Style: High-precision architectural section blueprint, technical circuit linework, dashed lines indicating data signal propagation, subtle gray panel textures (#F4F4F4), and bright red accents (#C8102E) highlighting RED classified network links and diode pathways.
```