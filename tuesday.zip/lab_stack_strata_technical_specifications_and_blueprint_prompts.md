# Lab Stack Strata — Architectural Blueprint Atlas & Prompt Catalog
**Reference Architecture:** `12 - Lab Stack Strata — Ground-Up Layer Matrix`  
**Targets:** Band A (Unclassified / CUI Lab) vs. Band B (Classified / SCIF Lab)  
**Circulation Paradigm:** External Mantrap Access into Central Corridor / Hallway

---

## Blueprint Generation Standard & Visual Rules

Each section elevation follows these architectural drafting constraints:
1. **Aspect Ratio:** 16:9 widescreen engineering sheet border with title block and graphic scale.
2. **Style:** Clean architectural section cut, high-contrast black vector-style outlines, subtle neutral fills (`#F4F4F4`), structural concrete hatch patterns, and strict red accent lines (`#C8102E`) for classified infrastructure, secure boundaries, and optical isolation.
3. **Spatial Distribution:**
   - **Far Left:** Exterior infrastructure / utility yard / primary services.
   - **Mid-Left:** Band A (Unclassified / CUI Lab enclave).
   - **Center:** Structural corridor hallway fed exclusively from an external interlocking mantrap airlock.
   - **Right:** Band B (Classified / SCIF Lab enclave) with reinforced physical, TEMPEST, and mechanical containment.

---

## Layer Catalog & Detailed Blueprint Specifications

### L0 · Power & Electrical Supply Chain

- **Description:** Ground-up electrical supply chain delivering isolated, resilient power from the utility grid to internal distribution boards and IT equipment.
- **Band A (Unclassified / CUI):** Standard dual-cord commercial feeds, commercial automatic transfer switch (ATS), and standard line-interactive/double-conversion UPS modules.
- **Band B (Classified / SCIF):** CTTA-compliant TEMPEST line filters positioned directly at the concrete SCIF boundary penetrations, N+1 parallel redundant double-conversion UPS battery banks (sized to ensure checkpoint completion during power loss), isolated technical PDUs, and a continuous equipotential copper grounding grid under the raised floor.
- **Reproduction Prompt:**
  > `An architectural cross-section blueprint drawing of Layer L0 Power and Electrical Supply Chain in ratio 16:9 with engineering title block and dimension lines. From left to right: Exterior utility pole transformer, diesel generator in underground fuel vault, automatic transfer switch; Band A (Unclassified CUI Lab) with commercial UPS and overhead dual-cord branch circuits; Center corridor hallway with an external secure airlock mantrap entrance; Band B (Classified SCIF Lab) with reinforced thick concrete slab, equipotential copper grounding mesh under raised floor, N+1 parallel redundant UPS cabinets, isolated technical PDU, and CTTA-compliant TEMPEST power line filters mounted where heavy conduits penetrate the SCIF wall. Clean technical linework, black architectural ink, selective red highlights for classified electrical lines, European competition board aesthetic.`

---

### L1 · Cooling & Thermal Chain

- **Description:** Thermal rejection infrastructure and environmental conditioning loops sized for high-density compute.
- **Band A (Unclassified / CUI):** Standard CRAC / CRAH perimeter units with overhead return ducting, relying primarily on forced convective air cooling.
- **Band B (Classified / SCIF):** Exterior closed-circuit dry coolers/chillers feeding a Coolant Distribution Unit (CDU) located in an isolated service mechanical room outside the SCIF white space. Non-conductive secondary loop pipes pass through acoustic/RF sleeves to direct-to-chip manifold racks. Subfloor stainless drip pans with continuous optical/conductive rope leak sensors. Chilled water telemetry monitored via an air-gapped data diode gateway.
- **Reproduction Prompt:**
  > `An architectural vertical cross-section blueprint of Layer L1 Cooling and Thermal Chain in ratio 16:9. Left: Exterior dry chillers and cooling towers with primary condenser water loop. Center-Left: Band A lab showing CRAC air handling units with standard overhead supply/return plenum ducting. Center: Central hallway with mantrap airlock. Right: Band B Classified SCIF lab showing an isolated Coolant Distribution Unit (CDU) room, non-conductive dielectric fluid lines penetrating SCIF boundary with acoustic sleeves, feeding in-rack direct-to-chip manifolds on dense GPU server racks, subfloor drip containment pans with rope leak-detection sensors, and a one-way telemetry diode gateway. Clean architectural style, technical cutaway hatching, subtle red highlighting.`

---

### L2 · Facility Shell & Structural Boundary

- **Description:** Structural envelope, physical hardening, acoustic baffles, and RF attenuation enclosures.
- **Band A (Unclassified / CUI):** Standard drywall-to-slab construction, standard acoustic drop-ceiling tiles, commercial hollow-metal doors, and perimeter wire-mesh fencing.
- **Band B (Classified / SCIF):** ICD 705 perimeter construction. Continuous 6-sided reinforced concrete envelope, 9-gauge expanded metal/welded steel mesh anti-intrusion layer, continuous RF shielding foil/mesh, STC 50+ acoustic insulation, RF waveguide honeycomb vents on all HVAC ducts, and a 360-degree inspectable perimeter crawl space (above ceiling and below floor).
- **Reproduction Prompt:**
  > `An architectural section elevation blueprint of Layer L2 Facility Shell and Structural Boundary, 16:9 aspect ratio. Band A on the left with conventional slab-to-deck drywall partitions and drop ceiling. Center corridor hallway with reinforced entryway. Band B on the right detailed as an accredited ICD 705 SCIF shell: floor-to-ceiling thick reinforced concrete walls, inspectable crawlway space above the ceiling and below the slab, expanded steel anti-intrusion mesh, continuous RF shielding foil, STC 50 acoustic sound attenuation batting, and RF honeycomb waveguide air vents on penetrations. Crisp architectural line art, detailed wall construction layers, annotations, subtle red accent on the secure SCIF boundary.`

---

### L3 · Facility Access & Physical Intrusion Detection (IDS)

- **Description:** Physical security, credential verification, intrusion detection systems, and surveillance zoning.
- **Band A (Unclassified / CUI):** Single-badge card access reader (ACS), mechanical locks, visitor sign-in kiosk, and standard interior dome cameras.
- **Band B (Classified / SCIF):** Dual-factor biometric + CAC/PIV authentication, interlocking mantrap vestibule with weight sensors (anti-tailgating) and overhead optical sensors, UL 2050 certified high-security switches (BMS) on all doors, balanced magnetic sensors, seismic vibration sensors on perimeter walls, and interior escort alert strobe lights.
- **Reproduction Prompt:**
  > `An architectural cross-section blueprint of Layer L3 Facility Access and Physical Intrusion Detection Systems (IDS), 16:9 ratio. Central focus on an external-access secure interlocking mantrap with dual interlocking steel doors, internal volumetric anti-tailgating presence sensors, and biometric retinal/fingerprint readers. Band A on left with standard proximity badge readers and visitor registry. Band B on right showing UL 2050 balanced magnetic switches on doors, PIR motion detectors, vibration sensors on reinforced concrete walls, CCTV cameras, and cleared escort indicator lights. Architectural draftsmanship, technical symbol annotations, red highlight lines.`

---

### L4 · Server Room & White Space Architecture

- **Description:** White space layout, environmental air containment, raceways, and spatial planning.
- **Band A (Unclassified / CUI):** Open server rows or simple cold-aisle plastic curtain containment, shared overhead basket trays for power and copper networking.
- **Band B (Classified / SCIF):** Fully enclosed hot-aisle containment (HAC) pods with rigid glass/steel ceiling panels, segregated physical raceways: isolated RED overhead fiber raceways (FiberRunner) physically separated from electrical runs by at least 1 meter, TEMPEST-rated zone shielding, and emergency power-off (EPO) stations with lift-covers.
- **Reproduction Prompt:**
  > `An architectural section elevation blueprint of Layer L4 Server Room White Space Architecture, 16:9 ratio. Left side Band A featuring open rack layouts with standard cold aisle strip curtains and shared overhead ladder racks. Center distribution corridor. Right side Band B Classified White Space featuring rigid hot-aisle containment (HAC) enclosures over server rows, floor-supported isolated RED fiber optic raceways strictly separated from subfloor power busways by physical distance, TEMPEST zone containment shields, overhead LED status beacons, and emergency power off stations. Precision vector lines, architectural callouts, red highlighted RED raceways.`

---

### L5 · Rack & Cabinet Infrastructure

- **Description:** Physical rack enclosures, mounting rails, rack PDUs, and internal thermal management.
- **Band A (Unclassified / CUI):** Standard 42U 4-post open or perforated steel server cabinets, standard vertical power strips, standard 19-inch mounting rails.
- **Band B (Classified / SCIF):** 48U heavy-duty seismic-rated welded server cabinets, mechanical key/combination lock handles with electronic audit logging, blanking panels in all empty RU slots to ensure static pressure, dual intelligent metered/switched rack PDUs (Circuit A & B), and internal liquid manifold drops with quick-disconnect couplings.
- **Reproduction Prompt:**
  > `An architectural cross-section blueprint of Layer L5 Rack and Cabinet Elevations, 16:9 ratio. Left Band A showing standard 42U server racks with generic PDU distribution and basic cable dressing. Right Band B Classified facility showing 48U heavy-duty seismic-rated server enclosures, electronic audit-logged door handles, blanking panels across unused rack units, dual vertical intelligent A/B PDUs with per-outlet monitoring, internal direct-to-chip quick-disconnect liquid cooling hoses, and red tamper-evident chassis tags. Clear CAD linework, crisp cross-sections, minimal red highlights on security locks.`

---

### L6 · Network Fabrics & Physical Cross-Domain Boundary

- **Description:** Transport networks, switching fabrics, physical isolation, and cross-domain data transfer appliances.
- **Band A (Unclassified / CUI):** Standard enterprise Top-of-Rack (ToR) 10/25GbE switching, shared management network, software VLAN segmentation.
- **Band B (Classified / SCIF):** Completely air-gapped RED compute fabric (Quantum-2 InfiniBand / 400GbE RoCE), dedicated out-of-band (OOB) BMC physical network, Type 1 HAIPE/KGV encryption devices at wide-area boundaries, and a certified hardware Data Diode (unidirectional fiber TX-only to RX-only transition) connecting low-side ingestion into the high-side enclave.
- **Reproduction Prompt:**
  > `An architectural section blueprint of Layer L6 Network Fabrics and Cross-Domain Boundaries, 16:9 ratio. Left: Band A CUI network switches with standard copper/fiber patch panels. Center wall: Hardware Data Diode appliance mounted across the boundary with an isolated one-way transmit-only fiber strand bridging into the classified space. Right: Band B Classified network showing air-gapped 400G InfiniBand leaf/spine fabric, physically separated Out-of-Band (OOB) BMC network switches, and Type 1 cryptographic devices. Clean technical drawing, dashed lines for signal paths, red dashed line for classified RED fabric.`

---

### L7 · Compute Hardware & Silicon Accelerators

- **Description:** High-density accelerator silicon, CPU host nodes, storage filers, and cryptographic modules.
- **Band A (Unclassified / CUI):** Commodity 1U/2U x86 CPU servers, mid-range PCIe GPUs (e.g., L40S) for development, local SATA/NVMe storage.
- **Band B (Classified / SCIF):** High-density 8-GPU HGX/DGX accelerator chassis (H100/H200/B200) with HBM memory, PCIe accelerator hosts with AMD/Xilinx Versal/Alveo FPGAs, high-speed NVMe all-flash arrays (hot storage), and hardware FIPS 140-3 Level 3 Hardware Security Modules (HSM).
- **Reproduction Prompt:**
  > `An architectural cross-section diagram of Layer L7 Compute Hardware and Accelerators, 16:9 ratio. Band A showing standard rack-mounted dual-socket CPU servers and entry-level PCIe GPU cards. Band B showing dense 8-GPU AI server chassis with liquid-cooled cold plates over high-bandwidth memory (HBM), adjacent FPGA acceleration chassis with PCIe external interconnects, an all-flash NVMe tier-1 storage array, and a dedicated PCIe Hardware Security Module (HSM). Detailed technical component elevation cutaways, vector line art, red accent labels.`

---

### L8 · Firmware, BMC & Hardware Root-of-Trust

- **Description:** Low-level silicon firmware, baseboard management controllers, and cryptographically verified boot chains.
- **Band A (Unclassified / CUI):** Standard vendor UEFI/BIOS, vendor BMC (iDRAC/iLO) connected to general corporate management subnets, automated vendor firmware updates over internet repos.
- **Band B (Classified / SCIF):** Hardware Root-of-Trust (RoT) with cryptographic signature validation at power-on, air-gapped offline firmware delivery mirrors, isolated OOB management fabric with strict access control, zero external internet reachability, and zeroized flash procedures.
- **Reproduction Prompt:**
  > `A technical architectural section blueprint of Layer L8 Firmware and BMC Security, 16:9 ratio. Diagrammatic cutaways showing server motherboards: Band A with standard BIOS/BMC firmware interfaces connected to standard management network. Band B with dedicated Hardware Root-of-Trust (RoT) chips, TPM 2.0 modules, isolated physical BMC connections routed exclusively to an internal air-gapped management network, and an offline local staging station for cryptographically signed firmware binaries. High-precision vector blueprint style with red accents.`

---

### L9 · Host Operating System & Hardware Drivers

- **Description:** Base operating system kernels, security-enhanced Linux baselines, and hardware-adjacent driver toolkits.
- **Band A (Unclassified / CUI):** Enterprise Linux (RHEL/Ubuntu) configured to NIST SP 800-171 guidelines, standard vendor repository mirrors, commercial NVIDIA driver/CUDA runtime.
- **Band B (Classified / SCIF):** DISA STIG-hardened Enterprise Linux OS, full-disk encryption (LUKS) with remote tang/clevis or HSM unlocking, pinned air-gapped CUDA and AMD XRT driver packages, offline repository mirrors, and strict SELinux mandatory access controls in enforcing mode.
- **Reproduction Prompt:**
  > `A clean architectural system stratum blueprint of Layer L9 Host OS and Driver Baseline, 16:9 ratio. Depicting server host software stacks: Band A showing standard Linux enterprise kernel with NIST 800-171 baseline and connected repository feeds. Band B showing DISA STIG hardened host OS boxes, SELinux enforcing mode boundary, LUKS encrypted partition blocks tied to network HSM keys, and offline pinned CUDA driver libraries. Technical architectural drafting aesthetic with clean lines and red structural boundary highlights.`

---

### L10 · Platform Orchestration & Cluster Management

- **Description:** Cluster schedulers, container orchestration engines, private container registries, and identity providers.
- **Band A (Unclassified / CUI):** Kubernetes or Slurm cluster federated with corporate Identity Provider (IdM) / Active Directory, cloud-connected container mirrors.
- **Band B (Classified / SCIF):** Fully autonomous air-gapped Kubernetes (K8s) or Slurm cluster, local private Harbor container registry with automated vulnerability scanning, air-gapped Keycloak/FreeIPA Identity Provider with multi-factor authentication, and Open Policy Agent (OPA) gatekeepers.
- **Reproduction Prompt:**
  > `An architectural system stratum section diagram of Layer L10 Platform Orchestration, 16:9 ratio. Left Band A showing container cluster orchestration tied to enterprise corporate SSO and cloud registries. Right Band B showing completely on-premises air-gapped Kubernetes and Slurm cluster controllers, internal secure Harbor container registry, local air-gapped IdM/MFA identity servers, and OPA policy engines enforcing cluster workload rules. Minimalist architectural engineering style with crisp black lines and red warning fills.`

---

### L11 · Application Workloads & AI Pipelines

- **Description:** Machine learning training runs, inference serving endpoints, retrieval-augmented generation (RAG), and DSP processing.
- **Band A (Unclassified / CUI):** Open-source LLM experimentation, RAG pipelines searching CUI technical documentation, unclassified research data stores.
- **Band B (Classified / SCIF):** Air-gapped classified model fine-tuning and inference serving (vLLM/Triton), compartmentalized RAG architecture with cryptographically enforced pre-retrieval access control lists (ACLs) on vector embeddings, Milvus/Qdrant vector databases, and real-time FPGA digital signal processing (DSP).
- **Reproduction Prompt:**
  > `An architectural systems blueprint of Layer L11 Application Workloads and AI Pipelines, 16:9 ratio. Left Band A showing standard ML pipelines and shared unclassified document stores. Right Band B showing high-security compartmentalized AI workloads: GPU fine-tuning jobs, isolated vLLM inference microservices, vector database nodes with strict pre-query document classification tagging, and FPGA real-time signal processing pipelines. Clean architectural diagram style, dashed flow paths, red security boundary indicators.`

---

### L12 · Assurance, Governance & Continuous Monitoring

- **Description:** Audit collectors, Security Information and Event Management (SIEM), compliance telemetry, and continuous authorization (cATO).
- **Band A (Unclassified / CUI):** CMMC Level 2 audit collectors, SPRS scoring evidence logs, centralized corporate syslog.
- **Band B (Classified / SCIF):** Continuous Authorization to Operate (cATO) telemetry bus, centralized air-gapped SIEM/Splunk collecting real-time logs from L0 through L11, hardware Data Diode audit logs, physical tamper event correlation, Software Bill of Materials (SBOM) and AI Model Lineage verification engines.
- **Reproduction Prompt:**
  > `An architectural cross-section blueprint of Layer L12 Assurance and Continuous Monitoring, 16:9 ratio. Left Band A showing CMMC audit logging engines and compliance repositories. Right Band B showing a classified continuous monitoring command dashboard, air-gapped SIEM ingestion nodes collecting telemetry from L0 power UPS, L1 cooling leaks, L3 physical IDS, L6 network firewalls, and L11 model queries, with SBOM attestation stores and cATO automated compliance engines. Technical blueprint drawing, architectural border, red alert highlighting.`