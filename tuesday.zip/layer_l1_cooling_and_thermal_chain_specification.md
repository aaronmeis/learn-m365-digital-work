# Stratum L1: Cooling & Thermal Chain Engineering Specification

**Strata Layer:** L1 (Outer Core / Thermal Rejection)  
**Parent Document:** `12 - Lab Stack Strata — Ground-Up Layer Matrix.md`  
**Security Classification Boundary:** Band A (CUI / Low-Side Enclave) vs. Band B (Classified / ICD 705 SCIF Enclave)  
**Circulation Paradigm:** External Mantrap Air-Lock Entry to Central Secure Corridor  

---

## 1. System Engineering Architecture

Layer L1 provides the primary thermodynamic dissipation and secondary distribution loops sizing the compute density for the entire facility. GPU dense clusters demand liquid direct-to-chip heat removal while conventional systems rely on forced air convection.

```text
[Exterior Dry Coolers / Chillers] 
       │ (Primary Condenser Loop: Treated Water/Glycol)
       ▼
 [Mechanical Room / Outside SCIF]
       │
  [CDU: Coolant Distribution Unit] (Plate Heat Exchanger & Pumps)
       ├──► Secondary Liquid Loop (Treated Water / Dielectric)
       │         │
       │         ▼ (Acoustic & Dielectric Sleeved Penetrations)
       │    [Band B SCIF / White Space] ──► Overhead/Subfloor Manifolds ──► Cold Plates (8-GPU Trays)
       │                                                                └──► Subfloor Drip Pans + Rope Sensors
       │
       └──► Secondary Air Loop
                 │
                 ▼
            [Band A CUI Lab] ─────────────► CRAC / In-Row Air Handlers ────► Overhead Return Plenum
```

---

## 2. Band A vs. Band B Detailed Technical Breakdown

| Metric / Component | Band A: Unclassified / CUI Lab | Band B: Classified / SCIF Lab |
| :--- | :--- | :--- |
| **Cooling Methodology** | Convective Air Cooling via In-Row CRAC units | Hybrid Direct-to-Chip (D2C) Liquid + Perimeter Air Handling |
| **Heat Density Capacity** | $10 \text{ kW} - 15 \text{ kW}$ per rack average | $40 \text{ kW} - 100 \text{ kW}+$ per rack (Liquid Cold Plate Loop) |
| **CDU Placement & Trust** | Shared mechanical space; unclassified maintenance | **Outside accredited SCIF space**; isolated mechanical room |
| **Boundary Penetration** | Standard non-rated pipe sleeves with firestop seals | **Dielectric break unions**, acoustic isolation boots, waveguide baffles |
| **Leak Detection** | Local point sensors under CRAC condensates | Dual-zone continuous conductive rope sensors in subfloor drip trays |
| **Environmental Telemetry** | BACnet/IP connected to central Building Automation (BAS) | Air-gapped one-way hardware **Data Diode gateway** to L12 SIEM |
| **Facility Maintenance Access**| Cleared or unescorted commercial vendor access | Escorted maintenance; zero uncleared access inside SCIF boundary |

---

## 3. Boundary & Physical Containment Details

1. **CDU Boundary Physical Separation:**
   * The Coolant Distribution Unit (CDU) sits in a dedicated mechanical utility chase outside the SCIF acoustic perimeter. This ensures uncleared mechanical contractors can service pumps, filters, and valves without entering the accredited area.
2. **Dielectric Isolation & Penetration Shielding:**
   * Stainless steel secondary cooling fluid lines entering the Band B SCIF must feature non-conductive dielectric isolation flanges to prevent radio frequency (RF) conduction into the shielded envelope.
   * Pipe penetrations pass through heavy steel sleeves welded to the continuous RF shielding mesh, packed with STC 50 acoustic neoprene packing.
3. **Subfloor Drip Containment:**
   * Underneath all liquid-cooled server racks in Band B, stainless steel drip containment pans (depth $\ge 75\text{ mm}$) run along the server footprint. Optical and conductive rope leak detection lines connect directly to the facility alarm and automated solenoid emergency shutoff valves.

---

## 4. Architectural Section Diagram Reproduction Prompt

Below is the detailed visual generation prompt to create the technical cross-section blueprint for this layer:

```text
An architectural cross-section blueprint drawing of Layer L1 Cooling & Thermal Chain, rendered in exact 16:9 widescreen format with an engineering title block, dimension lines, and architectural scale. 
Layout from left to right:
1. Far Left Exterior: Outdoor closed-circuit dry coolers, chillers, and primary condenser water loop with overflow retention sump.
2. Band A (Unclassified / CUI Lab): In-row CRAC air conditioning units, overhead supply and return air ductwork, perforated floor tiles, and low-density open lab air circulation.
3. Center Core: Structural corridor hallway accessed strictly from an external secure mantrap airlock; mechanical piping routed overhead through isolated utility channels.
4. Band B (Classified SCIF Lab): High-density liquid cooling loop featuring an isolated Coolant Distribution Unit (CDU) located in an external mechanical room; secondary dielectric liquid supply and return pipes penetrating the thick reinforced concrete SCIF wall via acoustic and RF-shielded sleeves; overhead rigid pipe manifolds with drop lines feeding direct-to-chip cold plates on dense 8-GPU server racks; subfloor stainless steel drip pans with continuous rope leak-detection sensors; and an air-gapped one-way telemetry diode gateway monitoring flow rate, pressure, and temperature.
Aesthetic: Crisp black CAD line art, vector hatching for concrete slabs and earth, subtle neutral panel fills (#F4F4F4), and selective red accent highlights (#C8102E) on classified liquid lines, leak sensors, and SCIF boundary seals. Professional European competition board layout, clean and precise.
```