# Stratum L8: Firmware, BMC & Hardware Root-of-Trust Specification

**Strata Layer:** L8 (Hardware OS Lower Half / Silicon Firmware & BMC)  
**Parent Document:** `12 - Lab Stack Strata — Ground-Up Layer Matrix.md`  
**Security Classification Boundary:** Band A (CUI Enclave) vs. Band B (ICD 705 SCIF Enclave)  
**Circulation Paradigm:** External Mantrap Air-Lock Entry to Central Secure Corridor  

---

## 1. System Engineering Architecture

Layer L8 represents the lowest layer of software execution: UEFI/BIOS firmware, Baseboard Management Controllers (BMC/iDRAC/iLO), GPU VBIOS, and FPGA bitstream shells. Band B enforces a complete physical air-gap for management, cryptographically signed firmware verification at boot, and an offline delivery path via Layer L6 data diodes.

```text
[External Firmware Vendor Releases]
                 │
                 ▼ (Manual Verification & Hash Comparison)
     [Band A Firmware Staging Host]
                 │
                 ▼ (Low-to-High Ingestion via L6 Data Diode)
     [Band B Offline Firmware Mirror]
                 │
                 ▼ (Air-Gapped Out-of-Band OOB Network)
   [Server Hardware Root-of-Trust (RoT)]
                 ├──► Cryptographic Signature Verification (TPM 2.0 / Cerberus)
                 ├──► Measured Boot Chain (UEFI / PCR Registers)
                 ├──► Isolated BMC Execution (iDRAC / iLO on dedicated physical port)
                 └──► GPU VBIOS & FPGA Shell Attestation
```

---

## 2. Band A vs. Band B Detailed Technical Breakdown

| Metric / Component | Band A: Unclassified / CUI Lab | Band B: Classified / SCIF Lab |
| :--- | :--- | :--- |
| **Boot Security** | Standard UEFI Secure Boot with Microsoft keys | **Measured Boot with Custom Hardware Root-of-Trust (RoT)** and TPM 2.0 PCR attestation |
| **BMC Network Reachability**| Dedicated VLAN routed across internal enterprise LAN | **Physically air-gapped OOB network**; zero route to corporate network or data fabric |
| **Firmware Update Mechanism**| Automated vendor update agents via internet repos | **Air-gap delivery only**: cryptographically signed blobs ingested through L6 diode |
| **GPU / Accelerator Firmware**| Standard NVIDIA driver flashing utility | **VBIOS verification via cryptographically locked hashes**; strict version locking |
| **FPGA Bitstream Security** | Unencrypted bitstreams during development | **AES-256 encrypted & RSA-4096 signed bitstreams** verified by FPGA silicon eFuses |
| **Supply Chain Attestation** | Standard hardware vendor delivery | **Signed Platform Certificates (TCG / IEEE 802.1AR)** verified upon receipt |

---

## 3. Measured Boot & Remote Attestation Workflow

1. **Hardware Root-of-Trust (RoT):**
   * Upon AC power application, the dedicated on-board RoT security chip (e.g., Google Titan, Microsoft Cerberus, or OpenTitan) powers up first. It verifies the digital signature of the BMC flash memory before permitting the BMC to release the host CPU from reset.
2. **Platform Configuration Registers (PCRs):**
   * As the system transitions through the UEFI boot stages, cryptographic hashes of the BIOS, RAID controller firmware, GPU VBIOS, and bootloader are extended into the TPM 2.0 PCRs. If any measurement deviates from the baseline hash, the server halts boot and alerts L12 assurance.

---

## 4. Architectural Section Diagram Reproduction Prompt

Below is the detailed visual generation prompt to create the technical cross-section blueprint for this layer:

```text
A technical architectural cross-section blueprint of Layer L8 Firmware, BMC & Hardware Root-of-Trust, 16:9 widescreen ratio with schematic logic cutaways.
Left to right layout:
1. Band A (Unclassified / CUI Node): Server motherboard cutaway showing standard commercial BIOS chip, standard BMC microcontroller connected via an internal trace to a shared onboard Ethernet NIC, and standard commercial UEFI boot status screen.
2. Center: Shielded conduit transit between facilities with optical diode bridge icon.
3. Band B (Classified SCIF Node): Motherboard schematic cutaway featuring a discrete Hardware Root-of-Trust (RoT) processor; TPM 2.0 cryptographic module; physically isolated Baseboard Management Controller (BMC) chip wired strictly to a shielded rear-panel Out-of-Band (OOB) Ethernet port; high-speed SPI bus with dual redundant flash memory banks; FPGA configuration interface showing eFuse key validation block; and a dedicated local air-gapped firmware staging station inside Band B showing cryptographic hash verification and signature validation screens.
Style: Detailed technical blueprint drafting, circuit trace line art, IC component schematics, neutral background tone (#F4F4F4), and bright red accents (#C8102E) highlighting the isolated OOB management paths, RoT chip boundaries, and secure firmware verification channels.
```