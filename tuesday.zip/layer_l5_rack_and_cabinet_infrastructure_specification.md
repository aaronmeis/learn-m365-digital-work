# Stratum L5: Rack & Cabinet Infrastructure Engineering Specification

**Strata Layer:** L5 (Mechanical Foundation / Racks & PDUs)  
**Parent Document:** `12 - Lab Stack Strata — Ground-Up Layer Matrix.md`  
**Security Classification Boundary:** Band A (CUI Enclave) vs. Band B (ICD 705 SCIF Enclave)  
**Circulation Paradigm:** External Mantrap Air-Lock Entry to Central Secure Corridor  

---

## 1. System Engineering Architecture

Layer L5 governs the physical enclosures housing the servers, network switches, and power conditioning units. Each cabinet serves as an independent failure domain, physical security zone, and thermodynamic envelope.

```text
                      [48U Server Rack Enclosure]
                                   │
         ┌─────────────────────────┼─────────────────────────┐
         ▼                         ▼                         ▼
[Dual Vertical Intelligent PDUs]  [In-Rack Direct Fluid CDU]  [Physical Cabinet Enclosure]
• Circuit A / Feed A (3-Phase)    • Top/Bottom Manifolds      • Seismic Zone 4 Welded Frame
• Circuit B / Feed B (3-Phase)    • Blind-Mate Quick Drops    • Dual Electronic Biometric Locks
• Per-Outlet Metering & Switching • Non-Spill Couplers        • Perforated Hex Front/Rear Doors
• Branch Circuit Monitoring       • Secondary Supply/Return   • Blanking Panels in All Empty RUs
```

---

## 2. Band A vs. Band B Detailed Technical Breakdown

| Metric / Component | Band A: Unclassified / CUI Lab | Band B: Classified / SCIF Lab |
| :--- | :--- | :--- |
| **Cabinet Dimensions** | 42U standard ($600\text{ mm W} \times 1070\text{ mm D}$) | **48U extra-deep ($800\text{ mm W} \times 1200\text{ mm D}$)** for GPU trays & liquid hoses |
| **Physical Enclosure Locks** | Standard mechanical key or 3-digit combination handle | **Smart electronic swinghandles with integrated multi-factor card reader** and audit log |
| **Thermal Blanking** | Plastic snap-in blanking panels | 1U/2U steel toolless blanking panels + horizontal brush strips to maintain static air pressure |
| **Rack PDU Configuration** | Dual 30A single-phase or 3-phase commercial PDUs | **Dual 60A 3-Phase $415\text{V}$ Intelligent Switched PDUs** with per-outlet kW metering |
| **Liquid Manifold Integration** | None (standard fan air-cooling) | Integrated dual vertical stainless steel liquid manifolds with blind-mate drip-free quick disconnects |
| **Weight & Ballast Rating** | Static load rating $\sim 1000\text{ kg}$ ($2200\text{ lbs}$) | **Heavy-duty dynamic load rating $\ge 1800\text{ kg}$ ($4000\text{ lbs}$)** with seismic tie-down brackets |
| **Chassis Tamper Detection** | None | Chassis microswitch tamper sensors connected to out-of-band security logger |

---

## 3. High-Density 48U Rack Unit (RU) Mapping

Below is the standard RU allocation profile for a Band B classified high-density GPU computing rack:

```text
 47U - 48U : Top-of-Rack (ToR) 400GbE / Quantum-2 InfiniBand Leaf Switches (RED Fabric)
 45U - 46U : Out-of-Band (OOB) BMC Management Switch + Terminal Server
 43U - 44U : Liquid Cooling Rack Manifold Air Purge & Diagnostic Header
 35U - 42U : 8-GPU Dense Accelerator Node 1 (DGX/HGX Form Factor, 8U)
 27U - 34U : 8-GPU Dense Accelerator Node 2 (DGX/HGX Form Factor, 8U)
 19U - 26U : 8-GPU Dense Accelerator Node 3 (DGX/HGX Form Factor, 8U)
 15U - 18U : 4U Tier-1 All-NVMe High-Speed Storage Target
 11U - 14U : FPGA Hardware Acceleration Host (Alveo / Versal PCIe)
  3U - 10U : CPU Worker & Control Plane Host Nodes
  1U - 2U  : Dual Dedicated Hardware Security Modules (HSM, FIPS 140-3)
```

---

## 4. Architectural Section Diagram Reproduction Prompt

Below is the detailed visual generation prompt to create the technical cross-section blueprint for this layer:

```text
An architectural section blueprint of Layer L5 Rack & Cabinet Infrastructure, 16:9 widescreen format with detailed RU elevation grid lines and dimension callouts.
Layout from left to right:
1. Band A (Unclassified / CUI Cabinet): Standard 42U server cabinet with generic perforated metal doors, basic vertical PDUs, mixed commodity servers, plastic blanking panels, and mechanical keyed door handles.
2. Center: Structural partition dividing the white spaces.
3. Band B (Classified SCIF High-Density Racks): Series of three heavy-duty 48U seismic-rated server cabinets ($800mm wide by 1200mm deep). Detail showing: dual vertical 3-phase intelligent power distribution units (PDU A and B) mounted on rear corners with glowing LED current displays; integrated vertical liquid cooling manifolds with braided stainless steel hoses dropping blind-mate quick-disconnect couplers into 8U GPU chassis; solid metal blanking panels across all unused RU slots; electronic keypad and smartcard locking door handles; internal chassis tamper-evident microswitches; and seismic base-plate anchor bolts locking the cabinet frame directly to the concrete sub-slab.
Style: Crisp CAD section cut, fine line weights, mechanical cross-hatching, clear RU unit labels, neutral background tones (#F4F4F4), and bright red accents (#C8102E) for intelligent PDU feeds, security lock LEDs, and classified rack tags.
```