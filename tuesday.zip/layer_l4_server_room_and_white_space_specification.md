# Stratum L4: Server Room & White Space Architecture Specification

**Strata Layer:** L4 (White Space / Aisle Containment & Pathways)  
**Parent Document:** `12 - Lab Stack Strata — Ground-Up Layer Matrix.md`  
**Security Classification Boundary:** Band A (CUI Enclave) vs. Band B (ICD 705 SCIF Enclave)  
**Circulation Paradigm:** External Mantrap Air-Lock Entry to Central Secure Corridor  

---

## 1. System Engineering Architecture

Layer L4 defines the white space layout, air containment systems, overhead cable distribution trays, grounding planes, and safety infrastructure. Band B establishes strict TEMPEST physical zones and isolated cable pathways to prevent electromagnetic eavesdropping or accidental cross-coupling between RED (classified) and BLACK (unclassified) lines.

```text
                    [Building Structural Ceiling Slab]
                               │
         ┌─────────────────────┴─────────────────────┐
         ▼                                           ▼
[Band A: Standard White Space]             [Band B: Accredited RED White Space]
• Shared wire-basket cable tray            • Fully Enclosed Hot-Aisle Containment (HAC)
• Flexible PVC cold-aisle strip curtains   • Rigid Aluminum/Glass Containment Roof & Doors
• Standard commercial raised floor (12")   • Heavy-Duty Bolted Pedestal Raised Floor (24"-36")
• Standard building grounding loop         • Separate RED FiberRunner vs. Power Trays ($\ge 1\text{m}$ gap)
• Commercial Clean Agent Fire Bottles      • TEMPEST Zone A/B Demarcation Lines on Slab
                                           • Lift-Cover Emergency Power Off (EPO) Stations
```

---

## 2. Band A vs. Band B Detailed Technical Breakdown

| Metric / Component | Band A: Unclassified / CUI Lab | Band B: Classified / SCIF Lab |
| :--- | :--- | :--- |
| **Aisle Containment** | Flexible vinyl/PVC strip curtains or open cold aisle | **Rigid Hot-Aisle Containment (HAC)** with tempered glass panels and auto-closing doors |
| **Overhead Cable Routing** | Single shared wire basket tray (power and data separated by divider) | **Physically separated yellow FiberRunner raceways for RED data**; separate enclosed metal conduit for power ($\ge 1000\text{ mm}$ physical separation) |
| **Raised Access Floor** | $300\text{ mm}$ ($12\text{ in}$) pedestals, light commercial floor tiles | $600\text{ mm} - 900\text{ mm}$ ($24-36\text{ in}$) heavy-load bolted-stringer pedestals with seismic bracing |
| **TEMPEST Demarcation** | No TEMPEST boundaries | Visible **RED/BLACK perimeter boundary tape** on floor tiles with certified setback clearances |
| **Fire Suppression** | Pre-action dry pipe sprinklers or clean agent (Novec 1230 / FM-200) | Dual-interlock pre-action clean agent system with early warning air-sampling detection (VESDA) |
| **Emergency Power Off (EPO)** | Wall-mounted break-glass EPO | Dual-action guarded lift-cover EPO buttons tied to UPS shunt-trip breakers |

---

## 3. TEMPEST Separation & Cable Pathway Enforcement

1. **RED/BLACK Pathway Separation:**
   * Fiber optic and copper raceways designated as RED (carrying classified plaintext) are routed through dedicated solid-wall or closed-trough yellow FiberRunner systems. They maintain a minimum physical standoff distance of $1000\text{ mm}$ ($39.4\text{ in}$) from non-TEMPEST power or building control cables to eliminate capacitive and inductive electromagnetic crosstalk.
2. **Aisle Containment Pressure Differential:**
   * The hot aisle containment pod operates under negative pressure relative to the surrounding white space, drawing cold air through the front of the servers and exhausting heated air into the overhead ceiling plenum return.

---

## 4. Architectural Section Diagram Reproduction Prompt

Below is the detailed visual generation prompt to create the technical cross-section blueprint for this layer:

```text
An architectural section elevation blueprint of Layer L4 Server Room White Space Architecture, 16:9 aspect ratio with CAD dimensions and detail tags.
Left to right layout:
1. Band A (Unclassified / CUI White Space): Raised access floor at 300mm height, standard server rack row with clear flexible vinyl cold-aisle strip curtains, overhead open wire-basket cable ladder carrying mixed cabling, and standard overhead commercial LED troffers.
2. Center: Fire-rated partition wall separating the white spaces from the central corridor hallway.
3. Band B (Classified SCIF White Space): Deep 600mm heavy bolted-stringer raised access floor with seismic turnbuckles; rigid Hot-Aisle Containment (HAC) structure with transparent overhead ceiling panels and sliding end-doors; overhead brightly colored yellow FiberRunner raceway carrying RED fiber optic cabling, physically suspended 1.2 meters away from isolated steel power conduit runs; high-sensitivity VESDA laser smoke detection sampling tubes; TEMPEST Zone A/B demarcation striping on floor tiles; and wall-mounted guarded emergency power-off (EPO) button stations.
Style: Professional architectural drawing with clean vector linework, structural cross-hatching, neutral white-space background (#F4F4F4), and vivid red accent lines (#C8102E) marking RED fiber raceways and TEMPEST demarcation perimeters.
```