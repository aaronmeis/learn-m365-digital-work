# Stratum L3: Facility Access & Intrusion Detection (IDS) Specification

**Strata Layer:** L3 (Upper Mantle / Physical Security & Access Control)  
**Parent Document:** `12 - Lab Stack Strata — Ground-Up Layer Matrix.md`  
**Security Classification Boundary:** Band A (CUI Enclave) vs. Band B (ICD 705 SCIF Enclave)  
**Circulation Paradigm:** External Mantrap Air-Lock Entry to Central Secure Corridor  

---

## 1. System Engineering Architecture

Layer L3 controls identity verification, physical ingress/egress authorization, and perimeter intrusion surveillance. Access into the facility is gated by an external mantrap airlock leading to a central distribution corridor before independent security checks control access into Band A or Band B.

```text
                    [Outside Public Exterior]
                               │
                               ▼
               [L3 External Mantrap Air-Lock]
     (Outer Blast Door + Weight Sensor + Dual Biometric/CAC Reader)
                               │
                               ▼
               [Central Secure Corridor / Hallway]
                               │
         ┌─────────────────────┴─────────────────────┐
         ▼                                           ▼
[Band A: CUI Access]                       [Band B: SCIF Access]
• PIV/CAC Proximity Badge                  • Dual-Factor Biometric + PIN
• Single Electrified Strike                • UL 2050 Balanced Magnetic Switch (BMS)
• Visitor Log Kiosk                        • Volumetric Dual-Tech Motion Sensors
• Standard Perimeter CCTV                  • Cleared Escort Strobe Indicators
                                           • Perimeter Vibration & Tilt Sensors
```

---

## 2. Band A vs. Band B Detailed Technical Breakdown

| Metric / Component | Band A: Unclassified / CUI Lab | Band B: Classified / SCIF Lab |
| :--- | :--- | :--- |
| **Authentication Form Factor** | Single-factor contact/contactless smartcard (CAC/PIV) | **Multi-factor: Biometric (Iris/Fingerprint) + PIN + PKI Card** |
| **Intrusion Detection (IDS)** | Commercial grade intrusion alarm panels | **UL 2050 / High-Security Balanced Magnetic Switches (BMS)** |
| **Anti-Tailgating Control** | Card-in / card-out software anti-passback | **Volumetric 3D optical sensors & floor load-cell weight scales** in mantrap |
| **Motion & Perimeter Sensors** | Standard passive infrared (PIR) room sensors | Combined Dual-Tech (PIR + Microphonic / Microwave) + Seismic wall sensors |
| **Visitor Management** | Sign-in kiosk, temporary paper/proximity badges | Escort-ratio protocols ($1:1$ or $1:4$), illuminated escort alert strobe lights |
| **Video Surveillance (CCTV)** | Standard commercial IP cameras recording to local NVR | NDAA-compliant, air-gapped secure IP cameras; **zero coverage of Classified monitors** |
| **Emergency Egress** | Standard panic hardware tied to fire alarm drop | Fail-secure magnetic locks with certified delayed egress panic hardware |

---

## 3. Mantrap Interlock Logic & Security Controls

1. **Two-Door Interlocking Sequence:**
   * Outer Door (D1) and Inner Door (D2) cannot be unlocked simultaneously. D1 must physically latch and the lock cylinder must be confirmed engaged by magnetic reed switches before D2 credential authentication is accepted.
2. **Anti-Tailgating Floor Scale:**
   * The mantrap cabin floor is fitted with calibrated weight load cells paired with an overhead optical sensor. If weight variance indicates multiple persons or unaccounted bulk materials during single-badge entry, the interlock locks down and alerts security.
3. **Escort Notification Beacons:**
   * When an uncleared vendor (such as a mechanical technician for L1 cooling) enters Band B under escort, overhead yellow/amber strobe beacons illuminate across all white space bays to alert cleared staff to blank displays and secure physical documentation.

---

## 4. Architectural Section Diagram Reproduction Prompt

Below is the detailed visual generation prompt to create the technical cross-section blueprint for this layer:

```text
An architectural cross-section blueprint of Layer L3 Facility Access & Intrusion Detection Systems (IDS) in 16:9 ratio with engineering dimension standards and callout annotations.
Layout from left to right:
1. Exterior Entry Mantrap: Highly detailed vertical section through the external-access interlocking security mantrap airlock showing exterior heavy blast door, biometric scanner pedestal, overhead volumetric anti-tailgate optical sensor, integrated floor scale weight sensors, and interlocking interior door opening into the central hallway.
2. Band A (Unclassified / CUI Lab): Conventional commercial badge reader, electrified mortise lock, ceiling-mounted commercial dome camera, and visitor registration station.
3. Center Corridor: Secure circulation hall with high-security door controllers, status indicators, and emergency delayed-egress panic push bars.
4. Band B (Classified SCIF Lab): High-security accredited access portal with dual-factor retinal scanner and keypad, UL 2050 certified triple-biased balanced magnetic switches (BMS) mounted on the door frame, wall-mounted seismic vibration detectors on the concrete perimeter, ceiling dual-technology PIR/microwave motion sensors, 360-degree covert dome cameras (angled strictly away from server displays), and overhead illuminated amber escort strobe lights.
Style: Crisp architectural CAD drawing, clean vector outlines, structural hatching, subtle light-gray paneling (#F4F4F4), and bright red accent lines (#C8102E) for high-security signal and sensor paths.
```